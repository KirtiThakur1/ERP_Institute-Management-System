<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from avant.redteamux.com/extras-signupform.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 30 Nov 2017 11:41:22 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <title>ERP-Signup</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Avant">
    <meta name="author" content="The Red Team"> 

    <link rel="stylesheet" href="assets/css/styles.minc726.css?=140">
    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600' rel='stylesheet' type='text/css'>
    
</head>
<body class="focusedform">

<div class="verticalcenter">
	<a href="index-2.html"><img src="assets/img/logo-big.png" alt="Logo" class="brand" /></a>
	<div class="panel panel-primary">
	<form action="signup-insert.php" method="post" class="form-horizontal" style="margin-bottom: 0px !important;">
				
		<div class="panel-body">
			<h4 class="text-center" style="margin-bottom: 25px;">Sign Up</h4>
						<div class="form-group">
							<div class="col-sm-12">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
									<input type="email" class="form-control" name="email_id" id="email_id" required aria-required="true" placeholder="Email">
								</div>
							</div>
						</div>
						
							<div class="form-group">
							<div class="col-sm-12">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-mobile"></i></span>
									<input type="tel" class="form-control" name="contact_number" id="contact_number" pattern="[7-9]{1}[0-9]{9}" title="Contact number with 7-9 and remaing 9 digit with 0-9" required placeholder="Contact Number">
								</div>
							</div>
						</div>
						
						
						<div class="form-group">
							<div class="col-sm-12">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-user"></i></span>
									<input type="text" class="form-control" name="user_name" id="user_name" required   placeholder="Username">
									 <!--<span id="name-format" class="help">Format: UserName</span>-->
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="col-sm-12">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock"></i></span>
									<input type="password" class="form-control" name="password" id="password"  required placeholder="Password">
								</div>
							</div>
						</div>
						<!--
						<div class="form-group">
							<div class="col-sm-12">
								<div class="input-group">
									<span class="input-group-addon"><i class="fa fa-lock"></i></span>
									<input type="password" class="form-control" id="password" placeholder="Repeat password">
								</div>
							</div>
						</div>
						-->
						<div class="block" style="text-align:center">
							<input type="checkbox" style="margin-right:5px" required>
							<span>
								I accept the <a href="#">User Agreement</a>
							</span>
						</div>
						
					
					
		</div>
		<div class="panel-footer">
			<div class="pull-left">
				<a href="extras-login.html" class="btn btn-default">Cancel</a>
			</div>
			<div class="pull-right">
				<input type="submit" class="btn btn-primary" name="submit" id="sign_up"value="Sign up"> 
			</div>
		</div>
		
		</form>
	</div>
 </div>
      
</body>

<!-- Mirrored from avant.redteamux.com/extras-signupform.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 30 Nov 2017 11:41:22 GMT -->
</html>