<div id="page-container">
        <!-- BEGIN SIDEBAR -->
        <nav id="page-leftbar" role="navigation">
                <!-- BEGIN SIDEBAR MENU -->
            <ul class="acc-menu" id="sidebar">
                <li id="search">
                    <a href="javascript:;"><i class="fa fa-search opacity-control"></i></a>
                     <form>
                        <input type="text" class="search-query" placeholder="Search...">
                        <button type="submit"><i class="fa fa-search"></i></button>
                    </form>
                </li>
                <li class="divider"></li> 
                <li><a href="index.php"><i class="fa fa-home"></i> <span>Dashboard</span></a></li>
                <li><a href="javascript:;"><i class="fa fa-th"></i> <span>Enquiry</span> </a>
                    <ul class="acc-menu">
                        <li><a href="enquiry.php">Add Enquiry</a></li>
						 <li><a href="enquiry-record.php">Manage Enquiry</a></li>
                    </ul>
                </li>
                <li><a href="javascript:;"><i class="fa fa-list-ol"></i> <span>Admissions</span></a>
                    <ul class='acc-menu'>
                        <li><a href="admission-form.php">Add Admission</a></li>
						 <li><a href="admission-records.php">Manage Admission</a></li>
                    </ul>
                </li>
                <li><a href="javascript:;"><i class="fa fa-tasks"></i> <span>Fees</span></a>
                    <ul class="acc-menu">
                        <li><a href="fee-form.php">Fee Section</a></li>
						 <li><a href="fee-record.php">Manage Fee</a></li>
                    </ul>
                </li>
                <li><a href="javascript:;"><i class="fa fa-table"></i> <span>Trainer</span></a>
                    <ul class="acc-menu">
                        <li><a href="trainer-form.php">Trainer Info</a></li>
						 <li><a href="trainer-record.php">Trainer Record</a></li>
                    </ul>
                </li>
                <li><a href="javascript:;"><i class="fa fa-pencil"></i> <span>User</span></a>
                    <ul class="acc-menu">
                        <li><a href="user-info.php">User Info</a></li>
						 <li><a href="user-record.php">User Record</a></li>
                    </ul>
                </li>
                <li><a href="javascript:;"><i class="fa fa-money"></i> <span>Expenses</span></a>
                    <ul class="acc-menu">
                        <li><a href="expenses-add.php">Expenses Record</a></li>
						 <li><a href="expenses-record.php">Manage Expenses</a></li>
                    </ul>
                </li>
                
                <li><a href="javascript:;"><i class="fa fa-bar-chart-o"></i> <span>Reports</span></a>
                    <ul class="acc-menu">
                        <li><a href="enquiryreportpage.php">Enquiry Reports</a></li>
						<li><a href="admissionreportpage.php">Admission Reports</a></li>
						<li><a href="feereportpage.php">Fee Reports</a></li>
						<li><a href="trainerreportpage.php">Trainer Reports</a></li>
						<li><a href="userreportpage.php">User Reports</a></li>
						<li><a href="expensesreportpage.php">Expenses Reports</a></li>
                    </ul>
                </li>
				<li>
				<a href ="globalsearchtest.php"><i class="fa fa-search"></i><span>Global Search</span></a>
				</li>
            </ul>
            <!-- END SIDEBAR MENU -->
        </nav>
		