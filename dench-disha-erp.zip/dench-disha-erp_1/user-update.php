<?php

include "config.php";

if(isset($_POST["update"]))
{
$user_id=$_POST["user_id"];	
$full_name=$_POST["full_name"];
$date_of_birth=$_POST["date_of_birth"];
$date_of_joining=$_POST["date_of_joining"];
$contact_number=$_POST["contact_number"];
$email_id=$_POST["email_id"];
$address=$_POST["address"];
$qualification=$_POST["qualification"];
$note=$_POST["note"];

date_default_timezone_set('Asia/Kolkata');
$currentTime = date( 'h:i:s A', time () );
$currentDate= date( 'd-m-Y', time () );
$currentDateTime=date( 'd-m-Y h:i:s A', time () );

//$created_by_id=NULL;
//$created_date=$currentDateTime; 

$last_modified_by_id=NULL;
$last_modified_date=$currentDateTime;


$update = ("UPDATE user SET full_name='".$full_name."', date_of_birth='".$date_of_birth."', date_of_joining='".$date_of_joining."', contact_number='".$contact_number."', email_id='".$email_id."', address='".$address."',qualification='".$qualification."',note='".$note."',last_modified_by_id='".$last_modified_by_id."',last_modified_date='".$last_modified_date."' WHERE user_id='".$user_id."'");
	
if(mysqli_query($conn, $update)){
	  echo "<script>alert('Record updated successfully!')</script>";
	 // echo "<script>window.location='ViewProduct.php?Id=" . $proId . "'</script>";
	 echo "<script>window.location='user-record.php'</script>";
	 
}else{
echo "Could not insert record: ". mysqli_error($conn);
}
mysqli_close($conn);

	
}

else{
	
	  echo "<script>alert('Record not updated!')</script>";
}


?>