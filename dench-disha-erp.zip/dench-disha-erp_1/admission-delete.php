<?php

require 'config.php';

	if(isset($_GET['Id']))
	{
		$admission_id=$_GET['Id'];
		
        $delete = ("DELETE FROM admission WHERE admission_id=".$admission_id."");
                    
		if(mysqli_query($conn, $delete)){ 
			
			echo "<script>alert('Admission record deleted')</script>";

			echo "<script>window.location='admission-records.php'</script>";
	 
		}else{
				echo "Could not delete record: ". mysqli_error($conn);
			}
		mysqli_close($conn);

	
	}

else{
	
	  echo "<script>alert('Record not deleted!')</script>";
}

         
?>
