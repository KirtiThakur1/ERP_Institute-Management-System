<?php

include "config.php";


$date=$_POST["date"];

$month=$_POST["month"];

$payment_mode=$_POST["payment_mode"];

$description=$_POST["description"];

$paid_amt=$_POST["paid_amt"];

$paid_by=$_POST["paid_by"];

$note=$_POST["note"];


date_default_timezone_set('Asia/Kolkata');
$currentTime = date( 'h:i:s A', time () );
$currentDate= date( 'd-m-Y', time () );
$currentDateTime=date( 'd-m-Y h:i:s A', time () );


$created_by_id=NULL;
$created_date=$currentDateTime;
$last_modified_by_id=NULL;
$last_modified_date=NULL;



$insert = "INSERT INTO expenses(date,month,payment_mode,description,paid_amount,paid_by,note,created_by_id,created_date,last_modified_by_id,last_modified_date) VALUES ('$date','$month','$payment_mode','$description','$paid_amt','$paid_by','$note','$created_by_id','$created_date','$last_modified_by_id','$last_modified_date')";
if(mysqli_query($conn, $insert)){
	  echo "<script>alert('Record inserted successfully!')</script>";
	 // echo "<script>window.location='ViewProduct.php?Id=" . $proId . "'</script>";
	 echo "<script>window.location='expenses-add.php'</script>";
	 
}else{
echo "Could not insert record: ". mysqli_error($conn);
}
mysqli_close($conn);




?>