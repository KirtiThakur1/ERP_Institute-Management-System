<?php

require 'config.php';

	if(isset($_GET['Id']))
	{
		$expenses_id=$_GET['Id'];
		
        $delete = ("DELETE FROM expenses WHERE expenses_id=".$expenses_id."");
                    
		if(mysqli_query($conn, $delete)){
			
			echo "<script>alert('Expenses record deleted')</script>";

			echo "<script>window.location='expenses-record.php'</script>";
	 
		}else{
				echo "Could not delete record: ". mysqli_error($conn);
			}
		mysqli_close($conn);

	
	}

else{
	
	  echo "<script>alert('Record not deleted!')</script>";
}

         
?>
