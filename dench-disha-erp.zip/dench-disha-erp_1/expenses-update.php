<?php

include "config.php";

if(isset($_POST["update"]))
{
$expenses_id=$_POST["expenses_id"];	
$date=$_POST["date"];
$month=$_POST["month"];
$payment_mode=$_POST["payment_mode"];
$description=$_POST["description"];
$paid_amount=$_POST["paid_amount"];
$paid_by=$_POST["paid_by"];
$note=$_POST["note"];

date_default_timezone_set('Asia/Kolkata');
$currentTime = date( 'h:i:s A', time () );
$currentDate= date( 'd-m-Y', time () );
$currentDateTime=date( 'd-m-Y h:i:s A', time () );

//$created_by_id=NULL;
//$created_date=$currentDateTime;

$last_modified_by_id=NULL;
$last_modified_date=$currentDateTime;


$update = ("UPDATE expenses SET date='".$date."', month='".$month."', payment_mode='".$payment_mode."', description='".$description."', paid_amount='".$paid_amount."',paid_by='".$paid_by."',note='".$note."',last_modified_by_id='".$last_modified_by_id."',last_modified_date='".$last_modified_date."' WHERE expenses_id='".$expenses_id."'");
	
if(mysqli_query($conn, $update)){
	  echo "<script>alert('Record updated successfully!')</script>";
	 // echo "<script>window.location='ViewProduct.php?Id=" . $proId . "'</script>";
	 echo "<script>window.location='expenses-record.php'</script>";
	 
}else{
echo "Could not insert record: ". mysqli_error($conn);
}
mysqli_close($conn);

	
}

else{
	
	  echo "<script>alert('Record not updated!')</script>";
}


?>