<?php

include "config.php";

$full_name=$_POST["full_name"];
$date_of_birth=$_POST["date_of_birth"];
$date_of_joining=$_POST["date_of_joining"];
$contact_number=$_POST["contact_number"];
$email_id=$_POST["email_id"];
$address=$_POST["address"];
$qualification=$_POST["qualification"];
$user_name=$_POST["user_name"];
$password=$_POST["password"];
$note=$_POST["note"];


date_default_timezone_set('Asia/Kolkata');
$currentTime = date( 'h:i:s A', time () );
$currentDate= date( 'd-m-Y', time () );
$currentDateTime=date( 'd-m-Y h:i:s A', time () );

$created_by_id=NULL;
$created_date=$currentDateTime;
$last_modified_by_id=NULL;
$last_modified_date=NULL;

$insert = "INSERT INTO user(full_name,date_of_birth,date_of_joining,contact_number,email_id,address,qualification,user_name,password,note,created_by_id,created_date,last_modified_by_id,last_modified_date) VALUES ('$full_name','$date_of_birth','$date_of_joining','$contact_no','$email_id','$address','$qualification','$user_name','$password','$note','$created_by_id','$created_date','$last_modified_by_id','$last_modified_date')";
if(mysqli_query($conn, $insert)){
	  echo "<script>alert('Record inserted successfully!')</script>";
	 // echo "<script>window.location='ViewProduct.php?Id=" . $proId . "'</script>";
	 echo "<script>window.location='user-record.php'</script>";
	 
}else{
echo "Could not insert record: ". mysqli_error($conn);
}
mysqli_close($conn);




?>