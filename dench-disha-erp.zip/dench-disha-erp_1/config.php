<?php

//Database connection  

$host_name = 'localhost:3306';
$user_name = 'root';
$password = '';
$database_name = 'ims_erp_db';
$conn = mysqli_connect($host_name, $user_name, $password, $database_name);
if(! $conn )
{
die('Could not connect: ' . mysqli_error());
}
else
{
	
//echo "<script>alert('Connected successfully')</script>";
//echo 'Connected successfully';
	
}

//mysqli_close($conn);

?>