<?php

include "config.php";

$full_name=$_POST["full_name"];

$course_id=$_POST["course_id"];

$course_name=$_POST["course_name"];

$course_fee=$_POST["course_fee"]; 

$discount_amt=$_POST["discount_amt"];

$amount_paid=$_POST["amount_paid"];

$remaining_amt=$_POST["remaining_amt"];

$status=$_POST["status"];

$admission_id=$_POST["admission_id"];


date_default_timezone_set('Asia/Kolkata');
$currentTime = date( 'h:i:s A', time () );
$currentDate= date( 'd-m-Y', time () );
$currentDateTime=date( 'd-m-Y h:i:s A', time () );


$created_by_id=NULL;
$created_date=$currentDateTime;
$last_modified_by_id=NULL;
$last_modified_date=NULL;



$insert = "INSERT INTO fee(full_name,course_id,course_name,admission_id,batch_and_timings,course_fees,discount_amount,amount_paid,remaining_amount,trainer,start_date,end_date,status,remarks,created_by_id,created_date,last_modified_by_id,last_modified_date) VALUES ('$full_name','$course_id','$course_name','$admission_id','$batch_time','$course_fee','$discount_amt','$amount_paid','$remaining_amt','$trainer','$start_date','$end_date','$status','$remarks','$created_by_id','$created_date','$last_modified_by_id','$last_modified_date')";
if(mysqli_query($conn, $insert)){
	  echo "<script>alert('Record inserted successfully!')</script>";
	 // echo "<script>window.location='ViewProduct.php?Id=" . $proId . "'</script>";
	 //echo "<script>window.location='fee-form.php'</script>";
	 
}else{
echo "Could not insert record: ". mysqli_error($conn);
}
mysqli_close($conn);




?>