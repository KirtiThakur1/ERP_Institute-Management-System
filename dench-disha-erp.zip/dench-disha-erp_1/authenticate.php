<?php

include('config.php');
 
session_start();
// If form submitted, insert values into the database.
if (isset($_POST['user_name'])){
        // removes backslashes
	$user_name = stripslashes($_REQUEST['user_name']);
        //escapes special characters in a string
	$user_name = mysqli_real_escape_string($conn,$user_name);
	$password = stripslashes($_REQUEST['password']);
	$password = mysqli_real_escape_string($conn,$password);
	//Checking is user existing in the database or not
        $query = "SELECT * FROM `user` WHERE user_name='$user_name'
and password='$password'";


		
	$result = mysqli_query($conn,$query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
        if($rows==1){
	    $_SESSION['user_name'] = $user_name;
		
		$stmt = $conn->query("SELECT * FROM `user` WHERE user_name='$user_name' and password='$password'"); 
        
	    while($row=$stmt->fetch_array())
		{
			extract($row);
			$_SESSION['user_id'] = $user_id;
		}
		
            // Redirect user to index.php
	    header("Location: index.php");
         }else{
	echo "<div class='form'>
<h3>user_name/password is incorrect.</h3>";
header("Location: login.php");
	}
    }
?>