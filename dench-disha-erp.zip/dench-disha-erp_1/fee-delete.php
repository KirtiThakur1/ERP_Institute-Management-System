<?php

require 'config.php';

	if(isset($_GET['Id']))
	{ 
		$fee_id=$_GET['Id'];
		
        $delete = ("DELETE FROM fee WHERE fee_id=".$fee_id."");
                    
		if(mysqli_query($conn, $delete)){
			
			echo "<script>alert('Fees record deleted')</script>";

			echo "<script>window.location='fee-record.php'</script>";
	 
		}else{
				echo "Could not delete record: ". mysqli_error($conn);
			}
		mysqli_close($conn);

	
	}

else{
	
	  echo "<script>alert('Record not deleted!')</script>";
}

         
?>
