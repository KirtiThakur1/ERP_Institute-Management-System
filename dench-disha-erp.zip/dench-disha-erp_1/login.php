<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from avant.redteamux.com/extras-login2.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 30 Nov 2017 11:41:22 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <title>ERP - LOGIN</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Avant">
    <meta name="author" content="The Red Team"> 

    <link rel="stylesheet" href="assets/css/styles.minc726.css?=140">
    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600' rel='stylesheet' type='text/css'>
    
</head>
<body class="focusedform">
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-44426473-2', 'auto');
  ga('send', 'pageview');

</script>
<div class="verticalcenter">
	<!--<a href="index.php"><img src="assets/img/logo-big.png" alt="Logo" class="brand" /></a>-->
	<div class="panel panel-primary">
		<div class="panel-body">
			<h4 class="text-center" style="margin-bottom: 25px;">Log in to get started</h4>
				<form id="login" name="login" action="authenticate.php" class="form-horizontal" method="post">
					<div class="form-group">
						<label for="username" class="control-label col-sm-4" style="text-align: left;">Username</label>
						<div class="col-sm-8">
							<input type="text" class="form-control" name="user_name" id="user_name" placeholder="Username">
						</div>
					</div>
					<div class="form-group">
						<label for="password" class="control-label col-sm-4" style="text-align: left;">Password</label>
						<div class="col-sm-8">
							<input type="password" class="form-control" name="password" id="password" placeholder="Password">
						</div>
					</div>
					<div class="clearfix">
						<div class="pull-right"><label><input type="checkbox" checked> Remember Me</label></div>
					</div>
					<input type="submit" name="submit" value="Log In" class="btn btn-primary btn-block">

					</form>
		</div>
		<div class="panel-footer">
			<a href="extras-forgotpassword.html" class="pull-left btn btn-link" style="padding-left:0">Forgot password?</a>
			
			<div class="pull-right">
			<input type="reset" name="reset" value="Reset" class="btn btn-default">
			</div>
			<div class="pull-right">
			<a href="signup.php"  name="singup" class="btn btn-default">Sign Up</a>
			</div>
		</div>
	</div>
 </div>

      
</body>

<!-- Mirrored from avant.redteamux.com/extras-login2.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 30 Nov 2017 11:41:22 GMT -->
</html>