<?php
	// include database connection file

	include "config.php";
	
	// fetch data from student table..
	 
	$output = "";
	if (isset($_POST['query'])) {
		$search = mysqli_real_escape_string($conn, $_POST['query']);
		//$sql = "SELECT * FROM  user WHERE full_name like '%$search%' OR contact_number like '%$search%'";
		//$sql = "SELECT user.*,enquiry.* FROM  user INNER JOIN enquiry ON user.user_id = enquiry.user_id AND full_name like '%$search%'";
		$sql = "SELECT user.*,enquiry.* FROM  user,enquiry WHERE user.user_id = enquiry.user_id AND user.full_name like '%$search%'";
	}else{
		//$sql = "SELECT * FROM user ORDER BY user_id DESC";
		$sql = "SELECT user.*,enquiry.* FROM  user,enquiry WHERE user.user_id = enquiry.user_id";
	}
	//echo $sql;
	$query = mysqli_query($conn, $sql);
	
	
	//if (mysqli_num_rows($query) > 0) {
		$output .= "<table class='table table-hover table-striped'>
		<thead>
			<tr>
				<th>User Id</th>
				<th>Firstname</th>
				<th>Contact No</th>
				<th>Email</th>
			</tr>
		</thead>";
		while ($row = mysqli_fetch_assoc($query)) {
		$output .= "<tbody>
			<tr>
				<td>{$row['user_id']}</td>
				<td>{$row['full_name']}</td>
				<td>{$row['contact_number']}</td>
				<td>{$row['email_id']}</td>
			</tr>
			</tbody>";
		}
	$output .="</table>";
		echo $output;
	//}
	//else{
		//echo "<h5>No record found</h5>";
//	}
	
?>