<?php

require 'config.php';

	if(isset($_GET['Id']))
	{
		$enquiry_id=$_GET['Id'];
		
        $delete = ("DELETE FROM enquiry WHERE enquiry_id=".$enquiry_id."");
                    
		if(mysqli_query($conn, $delete)){
			
			echo "<script>alert('Enquiry record deleted')</script>";

			echo "<script>window.location='enquiry-record.php'</script>";
	 
		}else{
				echo "Could not delete record: ". mysqli_error($conn);
			}
		mysqli_close($conn);

	
	}

else{
	
	  echo "<script>alert('Record not deleted!')</script>";
}

         
?>
