<?php

include "config.php";

if(isset($_POST["update"]))
{
$enquiry_id=$_POST["enquiry_id"];	
$followup=$_POST["followup"];

date_default_timezone_set('Asia/Kolkata');
$currentTime = date( 'h:i:s A', time () );
$currentDate= date( 'd-m-Y', time () );
$currentDateTime=date( 'd-m-Y h:i:s A', time () );

//$created_by_id=NULL;
//$created_date=$currentDateTime;

$last_modified_by_id=NULL;
$last_modified_date=$currentDateTime;


$insert = "INSERT INTO followup(followup_text,enquiry_id,created_by_id,created_date) VALUES ('$followup','$enquiry_id','$created_by_id','$created_date')";
	
if(mysqli_query($conn, $insert)){
	  echo "<script>alert('Record updated successfully!')</script>";
	 // echo "<script>window.location='ViewProduct.php?Id=" . $proId . "'</script>";
	 echo "<script>window.location='enquiry-record.php'</script>";
	 
}else{
echo "Could not insert record: ". mysqli_error($conn);
}
mysqli_close($conn);

	
}

else{
	
	  echo "<script>alert('Record not updated!')</script>";
}


?>