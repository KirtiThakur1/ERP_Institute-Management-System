<?php

require 'config.php';

	if(isset($_GET['Id']))
	{
		$user_id=$_GET['Id'];
		
        $delete = ("DELETE FROM user WHERE user_id=".$user_id."");
                    
		if(mysqli_query($conn, $delete)){
			 
			echo "<script>alert('User record deleted')</script>";

			echo "<script>window.location='user-record.php'</script>";
	 
		}else{
				echo "Could not delete record: ". mysqli_error($conn);
			}
		mysqli_close($conn);

	
	}

else{
	
	  echo "<script>alert('Record not deleted!')</script>";
}

         
?>
