	
	<?php
	session_start();
	
	include "config.php";
	
	if(isset($_GET['Id']))
        { 
			$admission_id=$_GET['Id']; //Accepted URL parameter
			
            $edit = $conn->query("SELECT * FROM admission WHERE admission_id=".$admission_id."");
            $row = $edit->fetch_array();
        }

?>													
														
														
														<!-- Modal -->
													

                                                        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog" role="document">
															<form action="fee-installments-insert.php?Id=<?php echo $admission_id; ?>" method="post" class="form-horizontal" style="margin-bottom: 0px !important;">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
																	<?php
																	$edit = $conn->query("SELECT * FROM admission WHERE admission_id=".$admission_id."");
																	$row1 = $edit->fetch_array();
																	echo $admission_id;
																	?>
																	
                                                                    <div class="modal-body">
                                                                        <div class="form-group">
																			<div class="row">
																			<div class="col-sm-3">
																			<label class="control-label">Full Name</label>
																			</div>
																			<div class="col-sm-3">
																			<input type="text" class="form-control" name="full_name" value="<?php echo $row1['full_name'];?>" placeholder="Full Name" readonly> 
																			</div>
                                        
																			</div> <!-- row end -->
																		</div> <!-- form-group end -->
																		
																		<div class="form-group">
																	<div class="row">
																	<div class="col-sm-2">
																		<label class="control-label">Course Id</label>
																	</div>
																	<div class="col-sm-4">
																		<input type="text" class="form-control" name="course_id" placeholder="Course Id.">
																	</div>
                                        
																	</div> <!-- row end -->
																</div> <!-- form-group end -->
                                
																<!-- Qualification & previous Knowledge-->
																	<div class="form-group">
																	<div class="row">
																	<div class="col-sm-2">
																		<label class="control-label">Course Name</label>
																	</div>
																	<div class="col-sm-4">
																		<input type="text" class="form-control" name="course_name" placeholder="Course Name">
																	</div>
																</div> <!-- row end -->
																</div> <!-- form-group end -->
																<div class="form-group">
																<div class="row">
																<div class="col-sm-2">
																	<label for="disabledinput" class="control-label">Course Fee</label>
																</div>
																<div class="col-sm-4">
																	<input type="text" class="form-control" name="course_fees" id = "course_fees" placeholder="">
																</div>
																</div> <!-- row end -->
																</div> 
								
												<div class="form-group">
													<div class="row">
													<div class="col-sm-2">
														<label class="control-label">Discount Amount</label>
													</div>
													<div class="col-sm-4">
													<input type="text" class="form-control" name="discount_amount" placeholder="">
													</div>
													</div> <!-- row end -->
												</div> 
												
														<div class="form-group">
															<div class="row">
															<div class="col-sm-2">
																<label class="control-label">Remaining Amount</label>
															</div>
															<div class="col-sm-4">
																<input type="text" class="form-control" name="remaining_amount" id = "remaining_amount" placeholder="" readonly>
															</div>
															</div> <!-- row end -->
														</div>
															
												<div class="form-group">
													<div class="row">
													<div class="col-sm-2">
														<label class="control-label">Amount Paid</label>
													</div>
													<div class="col-sm-4">
													<input type="text" class="form-control" name="amount_paid" id = "amount_paid" placeholder="">
													</div>
													</div> <!-- row end -->
												</div> 
												<div class="form-group">
															<div class="row">
															<div class="col-sm-2">
																<label class="control-label">After Paid Remaining Amount</label>
															</div>
															<div class="col-sm-4">
																<input type="text" class="form-control" name="after_paid_remaining_amount" id = "after_paid_remaining_amount" placeholder="" >
															</div>
															</div> <!-- row end -->
														</div>
												
															
                                
                                                            </div>
														
															
                                                            <div class="modal-footer">
                                                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
																
																	
																		<button type="submit" id = "submit" class="btn btn-primary">Save changes</button>
																	</form>
                                                            </div>
															
                                                            </div>
															</div>
                                                            </div>