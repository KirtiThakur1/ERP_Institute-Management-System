<?php

include "config.php";

date_default_timezone_set('Asia/Kolkata');
$currentTime = date( 'h:i:s A', time () );
$currentDate= date( 'd-m-Y', time () );
$currentDateTime=date( 'd-m-Y h:i:s A', time () );

$date_of_admission=NULL;
$created_by_id=NULL;
$created_date=$currentDateTime; 
$last_modified_by_id=NULL;
$last_modified_date=NULL;
$full_name=NULL;
$date_of_birth=NULL;
$contact_number=NULL;
$email_id=NULL;
$address=NULL;
$qualification=NULL;
$reference=NULL;
$note=NULL;
									
if(isset($_GET['Id']))
        {
			$enquiry_id=$_GET['Id']; //Accepted URL parameter
			
            $edit = $conn->query("SELECT * FROM enquiry WHERE enquiry_id=".$enquiry_id."");
            while($row=$edit->fetch_array())
			{
			extract($row);
			$insert = "INSERT INTO admission(full_name,date_of_birth,date_of_admission,contact_number,email_id,address,qualification,reference,note,created_by_id,created_date,last_modified_by_id,last_modified_date) VALUES ('$full_name','$date_of_birth','$date_of_admission','$contact_number','$email_id','$address','$qualification','$reference','$note','$created_by_id','$created_date','$last_modified_by_id','$last_modified_date')";
				if(mysqli_query($conn, $insert)){
			echo "<script>alert('Record converted to admission successfully!')</script>";
			//echo $insert;
	 // echo "<script>window.location='ViewProduct.php?Id=" . $proId . "'</script>";
	 echo "<script>window.location='admission-records.php'</script>";
				}	
		}
		}
else{
echo "Could not insert record: ". mysqli_error($conn);
}
mysqli_close($conn);						
        	



/*
echo $email_id;
echo "<br/>";


echo $contact_number;
echo "<br/>";


echo $user_name;
echo "<br/>";


echo $password;
echo "<br/>";
*/




?>