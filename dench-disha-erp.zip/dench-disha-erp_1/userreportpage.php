<?php

session_start();

if (!isset($_SESSION['user_name'])) {
    header('Location:login.php');
}
include "header.php";
include "config.php";
include "sidebar.php";
	
?>			

<!DOCTYPE html> 
<html lang="en">

<!-- Mirrored from avant.redteamux.com/form-layout.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 30 Nov 2017 11:37:12 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
	<meta charset="utf-8">
	<title>Avant</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Avant">
	<meta name="author" content="The Red Team">

    <link rel="stylesheet" href="assets/css/styles.minc726.css?=140">
    <link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600' rel='stylesheet' type='text/css'>

	 
        <link href='assets/demo/variations/default.css' rel='stylesheet' type='text/css' media='all' id='styleswitcher'> 
    
            <link href='assets/demo/variations/default.css' rel='stylesheet' type='text/css' media='all' id='headerswitcher'> 
    
	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries. Placeholdr.js enables the placeholder attribute -->
	<!--[if lt IE 9]>
        <link rel="stylesheet" href="assets/css/ie8.css">
		<script type="text/javascript" src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/respond.js/1.1.0/respond.min.js"></script>
        <script type="text/javascript" src="assets/plugins/charts-flot/excanvas.min.js"></script>
	<![endif]-->

	<!-- The following CSS are included as plugins and can be removed if unused-->

<link rel='stylesheet' type='text/css' href='assets/plugins/codeprettifier/prettify.css' /> 
<link rel='stylesheet' type='text/css' href='assets/plugins/form-toggle/toggles.css' /> 
</head>

<body class="">
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-44426473-2', 'auto');
  ga('send', 'pageview');

</script>
    <div id="headerbar">
        <div class="container">
            <div class="row">
                <div class="col-xs-6 col-sm-2">
                    <a href="#" class="shortcut-tiles tiles-brown">
                        <div class="tiles-body">
                            <div class="pull-left"><i class="fa fa-pencil"></i></div>
                        </div>
                        <div class="tiles-footer">
                            Create Post
                        </div>
                    </a>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <a href="#" class="shortcut-tiles tiles-grape">
                        <div class="tiles-body">
                            <div class="pull-left"><i class="fa fa-group"></i></div>
                            <div class="pull-right"><span class="badge">2</span></div>
                        </div>
                        <div class="tiles-footer">
                            Contacts
                        </div>
                    </a>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <a href="#" class="shortcut-tiles tiles-primary">
                        <div class="tiles-body">
                            <div class="pull-left"><i class="fa fa-envelope-o"></i></div>
                            <div class="pull-right"><span class="badge">10</span></div>
                        </div>
                        <div class="tiles-footer">
                            Messages
                        </div>
                    </a>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <a href="#" class="shortcut-tiles tiles-inverse">
                        <div class="tiles-body">
                            <div class="pull-left"><i class="fa fa-camera"></i></div>
                            <div class="pull-right"><span class="badge">3</span></div>
                        </div>
                        <div class="tiles-footer">
                            Gallery
                        </div>
                    </a>
                </div>

                <div class="col-xs-6 col-sm-2">
                    <a href="#" class="shortcut-tiles tiles-midnightblue">
                        <div class="tiles-body">
                            <div class="pull-left"><i class="fa fa-cog"></i></div>
                        </div>
                        <div class="tiles-footer">
                            Settings
                        </div>
                    </a>
                </div>
                <div class="col-xs-6 col-sm-2">
                    <a href="#" class="shortcut-tiles tiles-orange">
                        <div class="tiles-body">
                            <div class="pull-left"><i class="fa fa-wrench"></i></div>
                        </div>
                        <div class="tiles-footer">
                            Plugins
                        </div>
                    </a>
                </div>
                            
            </div>
        </div>
    </div>

        <!-- END RIGHTBAR -->
<div id="page-content">
	<div id="wrap">
		<div id="page-heading">
			<ol class="breadcrumb">
				<li><a href="index-2.html">Form</a></li>
				<li>User</li>
				<li class="active">User Report Form</li>
			</ol>

			<!--<h1>Forms</h1>
			<div class="options">
                <div class="btn-toolbar">
                    <div class="btn-group hidden-xs">
                        <a href='#' class="btn btn-default dropdown-toggle" data-toggle='dropdown'><i class="fa fa-cloud-download"></i><span class="hidden-sm"> Export as  </span><span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Text File (*.txt)</a></li>
                            <li><a href="#">Excel File (*.xlsx)</a></li>
                            <li><a href="#">PDF File (*.pdf)</a></li>
                        </ul>
                    </div>
                    <a href="#" class="btn btn-default"><i class="fa fa-cog"></i></a>
                </div>
            </div>-->
		</div>
		<div class="container">
		
			<!--<div class="alert alert-info">
				Use the <strong>same</strong> code as you would in <a class="alert-link" href="http://getbootstrap.com/">Twitter's Bootstrap 3.0</a>!
				<button type="button" class="close" data-dismiss="alert">&times;</button>
			</div>-->
			<div class="row">
				<div class="col-sm-12">
				  <div class="panel panel-primary">
				      <div class="panel-heading">
				          <h4>Report Form</h4>
				          
				      </div>
				      <div class="panel-body">
				      	<!--<h3>Basic Form Elements</h3>
						<p>Try resizing the window to see how the form adapts at smaller screen sizes!</p>
						<br>-->
						
						 <form method="post" class="form-horizontal" style="margin-bottom: 0px !important;"> 
						  <div class="form-group">
						    <label for="focusedinput" class="col-xs-1 ">From Date</label>
						    <div class="col-xs-3">
						      <input type="date" class="form-control input-sm" name = "from_date" id="from_date" value = "From Date" placeholder="">
						    </div>
							<label for="focusedinput" class="col-xs-1 ">To Date</label>
						    <div class="col-xs-3">
						      <input type="date" class="form-control input-sm" name = "to_date" id="to_date" placeholder="">
						    </div>
							<div class="col-xs-4">
						  	<!--<label for="selector1" class="col-sm-3 control-label"></label>-->
						  	<div class="col-sm-6"><select name="selector1" id="selector1" class="form-control" placeholder="Select Search Filter">
							<option>Select Search Filter</option>
						  		<option>ID</option>
						  		<option>full_name</option>
						  		<option>Contact No</option>
						  		<option>Email Id</option>
						  	</select></div>
						  </div>
						  </div>
						  <div class="form-group">
						  <div class="row">
						  <!--<label for="focusedinput" class="col-xs-6 "></label>-->
						    <div class="col-xs-8">
						      <input type="text" class="form-control input-sm" name = "keyword" id="keyword" placeholder="Search by ID,Name,Contact No,">
						    </div>
						    <!--<label for="focusedinput" class="col-xs-3 "></label>-->
						    <div class="col-xs-1">
						      <input type="submit" class="btn-default btn" name="submit" id="submit" value="Search">
							  
						    </div>
							
							<!--<label for="focusedinput" class="col-xs-3 "></label>-->
						    <div class="col-xs-2">
						      <link><a href = "userexportreport.php" name="export" id="export" >Click Here to Export Report</a></link>
						    </div>
							</div>
						  </div>
						</form>
			<div class="container">
            <div class="row">
              <div class="col-md-12">
                    <div class="panel panel-sky">
                        <div class="panel-heading">
                            <h4>Enquiry Record</h4>
                            <div class="options">   
                                <a href="javascript:;"><i class="fa fa-cog"></i></a>
                                <a href="javascript:;"><i class="fa fa-wrench"></i></a>
                                <a href="javascript:;" class="panel-collapse"><i class="fa fa-chevron-down"></i></a>
                            </div>
                        </div>
						
						 <div class="panel-body collapse in">
                            <table cellpadding="0" cellspacing="0" border="0" class="table table-striped table-bordered datatables" id="example">
                                <thead>
                                     <tr>
                                        <th>ID</th>
                                        <th>Full Name</th>
                                        <th>Date Of Birth</th>
										<th>Enquiry Date</th>
                                        <th>Contact No.</th>
                                        <th>Email Id</th>
										<th>Qualification</th>
                                    </tr>
                                </thead>

			
                                <tbody>
																
								 <?php
		
		if(isset($_POST['submit'])){
			
			$from_date=$_POST["from_date"];
			$to_date=$_POST["to_date"];
			$selector1=$_POST["selector1"];
			$keyword=$_POST["keyword"];
			
			if($from_date != 0 && $to_date != 0){
				$stmt = $conn->query("SELECT * FROM user WHERE date_of_joining BETWEEN '$from_date' AND '$to_date'");
			}
			elseif($keyword == NULL){
			$stmt = $conn->query("SELECT * FROM user");
			}elseif($keyword != NULL){
				$stmt = $conn->query("SELECT * FROM user WHERE full_name like '%$keyword%'");
			}
	    while($row=$stmt->fetch_array())
		{
			extract($row);
		
		
		
			?>
                           <tr>
									<td><?php echo $user_id;?></td>
									<td><?php echo $full_name;?></td>
									<td><?php echo $date_of_birth;?></td>
									<td><?php echo $date_of_joining;?></td>
									<td><?php echo $contact_number;?></td>
									<td><?php echo $email_id;?></td>
									<td><?php echo $qualification;?></td>
									
									
                                    </tr>
									
							<?php
		}
		}
	
?>
                                </tbody>
                            </table>
                        </div>
						
					
                    </div>
                </div>
            </div>

        </div> <!-- container -->
		
						
				      </div>
				      
				  </div>
				</div>
			</div>



		 </div> <!-- row -->
	 </div> <!-- container -->
 </div> <!-- wrap -->
</div> <!-- page-content -->
	
	
			
    <footer role="contentinfo">
        <div class="clearfix">
            <ul class="list-unstyled list-inline pull-left">
                <li>AVANT &copy; 2014</li>
            </ul>
            <button class="pull-right btn btn-inverse-alt btn-xs hidden-print" id="back-to-top"><i class="fa fa-arrow-up"></i></button>
        </div>
    </footer>

</div> <!-- page-container -->

	
<!--
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>

<script>!window.jQuery && document.write(unescape('%3Cscript src="assets/js/jquery-1.10.2.min.js"%3E%3C/script%3E'))</script>
<script type="text/javascript">!window.jQuery.ui && document.write(unescape('%3Cscript src="assets/js/jqueryui-1.10.3.min.js'))</script>
-->

<script type='text/javascript' src='assets/js/jquery-1.10.2.min.js'></script> 
<script type='text/javascript' src='assets/js/jqueryui-1.10.3.min.js'></script> 
<script type='text/javascript' src='assets/js/bootstrap.min.js'></script> 
<script type='text/javascript' src='assets/js/enquire.js'></script> 
<script type='text/javascript' src='assets/js/jquery.cookie.js'></script> 
<script type='text/javascript' src='assets/js/jquery.nicescroll.min.js'></script> 
<script type='text/javascript' src='assets/plugins/codeprettifier/prettify.js'></script> 
<script type='text/javascript' src='assets/plugins/easypiechart/jquery.easypiechart.min.js'></script> 
<script type='text/javascript' src='assets/plugins/sparklines/jquery.sparklines.min.js'></script> 
<script type='text/javascript' src='assets/plugins/form-toggle/toggle.min.js'></script> 
<script type='text/javascript' src='assets/js/placeholdr.js'></script> 
<script type='text/javascript' src='assets/js/application.js'></script> 
<script type='text/javascript' src='assets/demo/demo.js'></script> 

</body>

<!-- Mirrored from avant.redteamux.com/form-layout.php by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 30 Nov 2017 11:37:12 GMT -->
</html>