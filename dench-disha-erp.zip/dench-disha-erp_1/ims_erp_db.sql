-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2021 at 03:57 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ims_erp_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `admission_id` int(10) NOT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `date_of_birth` varchar(20) DEFAULT NULL,
  `date_of_admission` varchar(20) DEFAULT NULL,
  `contact_number` varchar(100) DEFAULT NULL,
  `email_id` varchar(20) DEFAULT NULL,
  `address` text,
  `qualification` varchar(50) DEFAULT NULL,
  `reference` text,
  `note` text,
  `created_by_id` int(20) DEFAULT NULL,
  `created_date` varchar(20) DEFAULT NULL,
  `last_modified_by_id` int(20) DEFAULT NULL,
  `last_modified_date` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admission`
--

INSERT INTO `admission` (`admission_id`, `full_name`, `date_of_birth`, `date_of_admission`, `contact_number`, `email_id`, `address`, `qualification`, `reference`, `note`, `created_by_id`, `created_date`, `last_modified_by_id`, `last_modified_date`) VALUES
(1, 'Devyani Inamdar', '4/10/1994', '5/5/2020', '916808024', 'devinamdar@gmail.com', 'Sinhgad Road,Pune', 'Mcs', 'Sourabh Buchake', '-', NULL, NULL, NULL, NULL),
(2, 'Sourabh Buchake', '21/3/1992', '6/5/2020', '831099887', 'sourabh.buchake@gmai', 'Sinhgad Road,Pune', 'BA', 'Friends', '-', NULL, NULL, NULL, NULL),
(3, 'Shrutika Parmar', '24/3/1994', '6/5/2020', '831099887', 'shruti.p@gmail.com', 'katraj,Pune', 'MCA', 'Friends', '-', NULL, NULL, NULL, NULL),
(4, 'Mrunal Kate', '25/8/1994', '8/6/2020', '831099887', 'mrunal.k.p@gmail.com', 'Dhanori,Pune', 'MCA', 'Devyani Inamdar', '-', NULL, NULL, NULL, NULL),
(5, 'Jyotsna Pardeshi', '29/4/1994', '10/7/2020', '831099887', 'jyo.p@gmail.com', 'katraj,Pune', 'MCA', 'Friends', '-', NULL, NULL, NULL, NULL),
(15, 'Ruchi Patki', '1996-09-06', '', '8989678765', 'Ruchi@gmail.com', '', 'BA', 'Devyani', '', 0, '07-12-2020 06:17:30 ', 0, ''),
(16, 'Prajakta', '2021-03-08', '', '7756462896', 'prajakta@gmail.com', 'sinhagad road', 'BCS', 'hghgj', '', 0, '18-03-2021 07:21:40 ', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(20) NOT NULL,
  `course_name` varchar(200) DEFAULT NULL,
  `fee` int(20) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `duration` varchar(100) DEFAULT NULL,
  `installment_facility` varchar(100) NOT NULL,
  `admission_id` int(20) NOT NULL,
  `created_by_id` int(11) NOT NULL,
  `created_date` varchar(100) DEFAULT NULL,
  `last_modified_id` int(10) DEFAULT NULL,
  `last_modified_date` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course_name`, `fee`, `description`, `duration`, `installment_facility`, `admission_id`, `created_by_id`, `created_date`, `last_modified_id`, `last_modified_date`) VALUES
(1, 'Web Development', 25000, '-', '6 Months', 'Yes', 15, 0, NULL, NULL, NULL),
(2, 'Android Development', 35000, '-', '6 Months', 'Yes', 0, 0, NULL, NULL, NULL),
(3, 'Core Java', 10000, '-', '1 Month', 'No', 0, 0, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `enquiry`
--

CREATE TABLE `enquiry` (
  `enquiry_id` int(20) NOT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `date_of_birth` varchar(20) NOT NULL,
  `enquiry_date` varchar(20) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email_id` varchar(20) NOT NULL,
  `address` text,
  `qualification` varchar(50) NOT NULL,
  `previous_knowledge` varchar(20) DEFAULT NULL,
  `course_name` varchar(20) NOT NULL,
  `fees` int(20) NOT NULL,
  `batch_and_timings` varchar(20) NOT NULL,
  `reference` text NOT NULL,
  `note` text,
  `created_by_id` int(20) DEFAULT NULL,
  `created_date` varchar(20) NOT NULL,
  `last_modified_by_id` int(20) DEFAULT NULL,
  `last_modified_date` varchar(20) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `enquiry`
--

INSERT INTO `enquiry` (`enquiry_id`, `full_name`, `date_of_birth`, `enquiry_date`, `contact_number`, `email_id`, `address`, `qualification`, `previous_knowledge`, `course_name`, `fees`, `batch_and_timings`, `reference`, `note`, `created_by_id`, `created_date`, `last_modified_by_id`, `last_modified_date`, `user_id`) VALUES
(1, 'Devyani Inamdar', '1994-10-04', '2020-06-04', '916808024', 'devinamdar@gmail.com', '  sinhgad Road,Pune', 'Mcs', 'Yes', 'Web Development', 30000, '6 to 7 pm', 'Sourabh Buchake', '-  ', 0, '', 0, '18-01-2021 04:29:59 ', 1),
(2, 'Makvika Khiste', '19/2/1992', '8/6/2020', '998988879', 'Mali.k@gmail.com', 'sinhgad Road,Pune', 'Mcom', 'Yes', 'Tally', 25000, '6 to 8 pm', 'Devyani Inamdar', '-', 0, '', 0, '', 0),
(3, 'Shruti Pandit', '13/8/1994', '5/8/2020', '916808904', 'shruti.pandit@gmail.', 'Swarget,Pune', 'Mcom', 'Yes', 'Tally', 30000, '8 to 9 am', 'Sourabh Buchake', '-', 0, '', 0, '', 5),
(4, 'Bhagyashree Kharmale', '29/2/1994', '10/9/2020', '816808024', 'Bhagu.k@gmail.com', 'sinhgad Road,Pune', 'Mcs', 'Yes', 'Web Development', 30000, '6 to 8 pm', 'Friends', '-', 0, '', 0, '', 0),
(5, 'Kirti Deo', '25/1/1993', '5/5/2020', '916909024', 'kirti_deo@gmail.com', 'sahakarnagar,Pune', 'GD Art', 'Yes', '3D Animation', 20000, '3 to 4 pm', 'Friends', '-', 0, '', 0, '', 0),
(6, 'Shivani Godbole', '1996-12-07', '2020-10-21', '9078987654', 'shivani@gmail.com', '  Sinhgad Road Pune ', 'BBA', 'C', 'C++', 25000, '7 to 8 pam', 'Devyani', ' ---  ', 0, '07-12-2020 06:09:55 ', 0, '14-12-2020 07:26:15 ', 0),
(7, 'Ruchi Patki', '1996-09-06', '2020-12-12', '8989678765', 'Ruchi@gmail.com', '  ', 'BA', 'C', 'Web Development', 15000, '7 to 8 pm', 'Devyani', '  ', 0, '07-12-2020 06:17:30 ', 0, '21-01-2021 05:35:30 ', 0),
(8, 'Kirti Thakur', '2021-03-01', '2021-03-16', '8806938152', 'kirti@gmail.com', 'dhairy', 'B.Tech', 'c++', 'Php', 45456, '6-7 pm', 'hghgj', '', 0, '18-03-2021 07:20:49 ', 0, '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `expenses_id` int(20) NOT NULL,
  `date` varchar(20) DEFAULT NULL,
  `month` varchar(20) DEFAULT NULL,
  `payment_mode` text,
  `description` text,
  `paid_amount` varchar(20) DEFAULT NULL,
  `paid_by` varchar(20) DEFAULT NULL,
  `note` text,
  `created_by_id` int(20) DEFAULT NULL,
  `created_date` varchar(20) DEFAULT NULL,
  `last_modified_by_id` int(20) DEFAULT NULL,
  `last_modified_date` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`expenses_id`, `date`, `month`, `payment_mode`, `description`, `paid_amount`, `paid_by`, `note`, `created_by_id`, `created_date`, `last_modified_by_id`, `last_modified_date`) VALUES
(1, '2020-12-10', 'December', 'Cash', 'Cash Deposited', ' 25000', 'Devyani Inamdar', '- ', NULL, NULL, 0, '18-12-2020 01:00:15 '),
(2, '7/5/2020', 'June', 'Cash', 'Cash Deposited', '20000', 'Shrutika Parmar', '-', NULL, NULL, NULL, NULL),
(3, '8/5/2020', 'May', 'Gpay', 'Gpay Transfer', '20000', 'Sourabh Buchake', '-', NULL, NULL, NULL, NULL),
(4, '10/6/2020', 'June', 'Gpay', 'Gpay Transfer', '20000', 'Mrunal kate', '-', NULL, NULL, NULL, NULL),
(5, '10/7/2020', 'July', 'Cash', 'Cash Transfer', '25000', 'Jyotsna Pardeshi', '-', NULL, NULL, NULL, NULL),
(7, '2020-12-12', '', 'Online', 'Gpay Transfer', '20000', '', 'xyz1234 ', 0, '12-12-2020 06:35:06 ', 0, '18-03-2021 07:40:42 '),
(8, '2021-03-01', 'march', 'cash', '-', '', 'Mr.Prashant Thakur', '-', 0, '18-03-2021 07:40:15 ', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `fee`
--

CREATE TABLE `fee` (
  `fee_id` int(10) NOT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `course_id` int(20) DEFAULT NULL,
  `course_name` varchar(20) DEFAULT NULL,
  `admission_id` int(11) NOT NULL,
  `batch_and_timings` varchar(20) NOT NULL,
  `course_fees` int(20) NOT NULL,
  `discount_amount` varchar(20) NOT NULL,
  `amount_paid` int(20) NOT NULL,
  `remaining_amount` int(20) NOT NULL,
  `trainer` varchar(20) NOT NULL,
  `start_date` varchar(20) NOT NULL,
  `end_date` varchar(20) NOT NULL,
  `status` text,
  `remarks` text,
  `created_by_id` int(20) NOT NULL,
  `created_date` varchar(20) NOT NULL,
  `last_modified_by_id` int(20) NOT NULL,
  `last_modified_date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fee`
--

INSERT INTO `fee` (`fee_id`, `full_name`, `course_id`, `course_name`, `admission_id`, `batch_and_timings`, `course_fees`, `discount_amount`, `amount_paid`, `remaining_amount`, `trainer`, `start_date`, `end_date`, `status`, `remarks`, `created_by_id`, `created_date`, `last_modified_by_id`, `last_modified_date`) VALUES
(1, 'Anajali Khandekar', 8904, 'Web Development', 0, '6 pm to 7 pm', 25000, '1000', 20000, 4000, 'Kapil Sir', '2020-06-20', '2020-01-20', '2020-01-20', '', 0, '11-12-2020 07:01:43 ', 0, '18-12-2020 11:46:29 '),
(2, 'Krutika A', 8903, 'Android', 0, '6 pm to 7 pm', 25000, '1000', 20000, 4000, 'Kapil Sir', '2020-06-20', '2020-01-20', 'hghjjk', 'hjhjk', 0, '11-12-2020 07:05:12 ', 0, ''),
(4, 'Ruchi Patki', 1, 'Web Development', 15, '6 to 7 pm', 25000, '0', 10000, 15000, 'Kapil Sir', '2021-01-04', '2021-06-04', '-', '-', 0, '21-01-2021 06:14:45 ', 0, ''),
(5, 'Ruchi Patki', 1, 'Web Development', 15, '', 25000, '0', 10000, 5000, '', '', '', NULL, NULL, 0, '', 0, ''),
(6, 'Janani Shekharan', 1, 'Php', 0, '6-7 pm', 5000, '-', 4587, 500, 'MR.KAPIL', '2021-03-15', '2021-03-24', '', '', 0, '18-03-2021 07:22:46 ', 0, ''),
(7, 'Janani Shekharan', 1, 'Php', 0, '6-7 pm', 5000, '-', 4587, 500, 'MR.KAPIL', '2021-03-15', '2021-03-24', '', '', 0, '18-03-2021 07:23:09 ', 0, ''),
(8, 'Srushti Salekar', 5, 'Php', 0, '6-7 pm', 6000, '-', 4000, 2000, 'MR.KAPIL', '2020-07-05', '2020-08-11', '', '', 0, '18-03-2021 07:31:20 ', 0, ''),
(9, 'Srushti Salekar', 5, 'Php', 0, '6-7 pm', 6000, '-', 4000, 2000, 'MR.KAPIL', '2020-07-05', '2020-08-11', '', '', 0, '18-03-2021 07:31:20 ', 0, ''),
(10, 'Kirti Thakur', 1, 'Php', 0, '6-7pm', 4587, '0', 4587, 0, 'MR.KAPIL', '2021-03-12', '2021-03-30', '', '', 0, '18-03-2021 07:33:45 ', 0, ''),
(11, 'Srushti Salekar', 5, 'Php', 0, '6-7 pm', 6000, '-', 4000, 2000, 'MR.KAPIL', '2020-07-05', '2020-08-11', '', '', 0, '18-03-2021 07:34:14 ', 0, ''),
(12, '', 0, '', 0, '', 0, '', 0, 0, '', '', '', '', '', 0, '18-03-2021 07:52:14 ', 0, ''),
(13, '', 0, '', 0, '', 0, '', 0, 0, '', '', '', '', '', 0, '18-03-2021 07:57:19 ', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `followup`
--

CREATE TABLE `followup` (
  `followup_id` int(11) NOT NULL,
  `followup_text` varchar(250) DEFAULT NULL,
  `enquiry_id` int(11) DEFAULT NULL,
  `created_by_id` int(11) DEFAULT NULL,
  `created_date` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `followup`
--

INSERT INTO `followup` (`followup_id`, `followup_text`, `enquiry_id`, `created_by_id`, `created_date`) VALUES
(1, ' 1st Enquiry Done - 10-06-2020', 1, 0, ''),
(2, ' Done', 1, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `trainer`
--

CREATE TABLE `trainer` (
  `trainer_id` int(20) NOT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `date_of_birth` varchar(20) DEFAULT NULL,
  `date_of_joining` varchar(20) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `email_id` varchar(20) DEFAULT NULL,
  `address` text,
  `qualification` varchar(20) DEFAULT NULL,
  `note` text,
  `created_by_id` int(20) NOT NULL,
  `created_date` varchar(20) NOT NULL,
  `last_modified_by_id` int(20) NOT NULL,
  `last_modified_date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trainer`
--

INSERT INTO `trainer` (`trainer_id`, `full_name`, `date_of_birth`, `date_of_joining`, `contact_number`, `email_id`, `address`, `qualification`, `note`, `created_by_id`, `created_date`, `last_modified_by_id`, `last_modified_date`) VALUES
(1, 'S B Jadhav', '1982-12-12', '2019-01-02', '8978675645', '', '', 'B.E', 'xyz', 0, '14-12-2020 06:32:46 ', 0, ''),
(2, ' Shivani G', '1991-02-02', '2020-03-12', '7898765456', '', '', 'BE', 'xyz', 0, '14-12-2020 07:32:41 ', 0, ''),
(3, 'Prajakta', '1999-02-18', '2021-03-14', '', 'prajakta@gmail.com', 'dhairy phata', 'B.Tech', '-', 0, '18-03-2021 07:37:45 ', 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `full_name` varchar(200) DEFAULT NULL,
  `date_of_birth` varchar(20) NOT NULL,
  `date_of_joining` varchar(20) NOT NULL,
  `contact_number` varchar(20) NOT NULL,
  `email_id` varchar(20) NOT NULL,
  `address` text,
  `qualification` varchar(20) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `password` varchar(20) NOT NULL,
  `note` text,
  `created_by_id` int(20) NOT NULL,
  `created_date` varchar(20) NOT NULL,
  `last_modified_by_id` int(20) NOT NULL,
  `last_modified_date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `full_name`, `date_of_birth`, `date_of_joining`, `contact_number`, `email_id`, `address`, `qualification`, `user_name`, `password`, `note`, `created_by_id`, `created_date`, `last_modified_by_id`, `last_modified_date`) VALUES
(1, 'Devyani Inamdar', '4/10/1994', '12/6/2020', '916808024', 'devinamdar@gmail.com', 'Sinhgad Road,Pune', 'Mcs', 'Devyani', 'Devyani', '-', 0, '', 0, ''),
(2, 'Admin', '', '', '9168080249', 'devinamdar4@gmail.co', ' ', '', 'Admin', 'Admin123', ' ', 0, '03-12-2020 07:09:10 ', 0, '16-12-2020 03:35:18 '),
(5, 'Shruti Pandit', '', '', '8329886310', 'shrutip@gmai', '', '', 'Sourabh', 'Sourabh123', '', 0, '07-12-2020 12:56:38 ', 0, ''),
(6, 'Vivek Inamdar', '1955-02-12', '2020-12-11', '9922638632', 'vivek@gmail.com', '', 'ITI', '', '', '-', 0, '07-12-2020 01:00:09 ', 0, ''),
(11, 'Anajali K', '1994-12-06', '2020-02-10', '9098809080', 'Anjali@gmail.com', ' Amaravati', 'B.E', '', '', ' --', 0, '11-12-2020 07:00:15 ', 0, '16-12-2020 03:37:07 '),
(13, 'S B Jadhav', '1982-12-12', '2019-03-01', '8978654545', '', '', 'BE', '', '', 'xyz', 0, '14-12-2020 06:22:24 ', 0, ''),
(14, 'Kirti Thakur', '1999-07-01', '2021-03-01', '', 'kirti@gmail.com', 'CWPRS colony,Kirkatwadi', 'B.Tech', 'admin', 'admin123', '', 0, '18-03-2021 07:39:19 ', 0, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`admission_id`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `enquiry`
--
ALTER TABLE `enquiry`
  ADD PRIMARY KEY (`enquiry_id`),
  ADD UNIQUE KEY `enquiry_id` (`enquiry_id`,`contact_number`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`expenses_id`);

--
-- Indexes for table `fee`
--
ALTER TABLE `fee`
  ADD PRIMARY KEY (`fee_id`);

--
-- Indexes for table `followup`
--
ALTER TABLE `followup`
  ADD PRIMARY KEY (`followup_id`);

--
-- Indexes for table `trainer`
--
ALTER TABLE `trainer`
  ADD PRIMARY KEY (`trainer_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `admission_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `enquiry`
--
ALTER TABLE `enquiry`
  MODIFY `enquiry_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `expenses`
--
ALTER TABLE `expenses`
  MODIFY `expenses_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `fee`
--
ALTER TABLE `fee`
  MODIFY `fee_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `followup`
--
ALTER TABLE `followup`
  MODIFY `followup_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `trainer`
--
ALTER TABLE `trainer`
  MODIFY `trainer_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
