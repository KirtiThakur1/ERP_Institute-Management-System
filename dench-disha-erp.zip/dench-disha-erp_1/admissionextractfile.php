
<?php

include "config.php";  
/*$conn = new mysqli('localhost', 'root', '');  
mysqli_select_db($conn, 'ims_erp_db'); */
			$from_date=$_POST["from_date"];
			$to_date=$_POST["to_date"];
			$selector1=$_POST["selector1"]; 
			$keyword=$_POST["keyword"];
		
			if($from_date != 0 && $to_date != 0){
				$stmt = $conn->query("SELECT admission_id,full_name,date_of_admission,contact_number,qualification FROM admission WHERE date_of_admission BETWEEN '$from_date' AND '$to_date'");
			}
			elseif($keyword == NULL){
			$stmt = $conn->query("SELECT admission_id,full_name,date_of_admission,contact_number,qualification FROM admission");
			}elseif($keyword != NULL){
				$stmt = $conn->query("SELECT admission_id,full_name,date_of_admission,contact_number,qualification FROM admission WHERE full_name like '%$keyword%'");
			}
/*$sql = "SELECT enquiry_id,full_name,enquiry_date FROM enquiry";  
$setRec = mysqli_query($conn, $stmt);*/  
$columnHeader = '';  
$columnHeader = "Admission Id" . "\t" . "Full Name" . "\t" . "Admission Date" . "\t" . "Contact No" . "\t" . "Qualification" . "\t";  
$setData = '';  
  while ($rec = mysqli_fetch_row($stmt)) {  
    $rowData = '';  
    foreach ($rec as $value) {  
        $value = '"' . $value . '"' . "\t";  
        $rowData .= $value;  
    }  
    $setData .= trim($rowData) . "\n";  
}  
  
header("Content-type: application/octet-stream");  
header("Content-Disposition: attachment; filename=AdmissionReport_Detail.xls");  
header("Pragma: no-cache");  
header("Expires: 0");  

  echo ucwords($columnHeader) . "\n" . $setData . "\n";  
 ?>