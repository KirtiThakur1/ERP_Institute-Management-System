<html>
<head>
<title>jQuery Real Time Calculations</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script>
  
          
       jQuery(function ($) { 
        
            $('#total_fees,#remaining_fees,#paid_fees').on('keyup', function () {
        
            var total_fees = $('#total_fees').val();            
            //$('#total_fees2').val(parseFloat(total_fees2));
            
            var remaining_fees = $('#remaining_fees').val();
            //$('#remaining_fees2').val(parseFloat(remaining_fees2));
            
            var paid_fees = $('#paid_fees').val();
            //$('#paid_fees2').val(parseFloat(paid_fees2));
            
          
            $('#after_paid_remaining_fees').val((parseFloat(remaining_fees)) - (parseFloat(paid_fees)));                   
          
            
                    //NumToWord((final_total_amount), 'inWords');
                    //$('#inWords').val(parseFloat(total));                 

                });
            });
               
          
        </script>
</head>
<body>
<h1>jQuery Real Time Calculations</h1>
<form id="" name="" action="" method="">

Total Fees: <input type="text" id="total_fees" name="total_fees" value="10000" placeholder="Total Fees"  readonly />
<br/>
<br/>
Remaining Fees: <input type="text" id="remaining_fees" name="remaining_fees" value="2000" placeholder="Remaining Fees" readonly />
<br/>
<br/>
Paid Fees: <input type="text" id="paid_fees" name="paid_fees" value="" placeholder="Paid Fees"/>
<br/>
<br/>
After Paid Remaining Fees: <input type="text" id="after_paid_remaining_fees" name="after_paid_remaining_fees" value="" placeholder="After Paid Remaining Fees"  />
<br/>

</form>

</body>


    

</html>