<?php

include "config.php";


$email_id=$_POST["email_id"];

$contact_number=$_POST["contact_number"];

$user_name=$_POST["user_name"];

$password=$_POST["password"]; 


$full_name=NULL;
$date_of_birth=NULL;
$date_of_joining=NULL;
$address=NULL;
$qualification=NULL;
$note=NULL;


date_default_timezone_set('Asia/Kolkata');
$currentTime = date( 'h:i:s A', time () );
$currentDate= date( 'd-m-Y', time () );
$currentDateTime=date( 'd-m-Y h:i:s A', time () );


$created_by_id=NULL;
$created_date=$currentDateTime;
$last_modified_by_id=NULL;
$last_modified_date=NULL;



$insert = "INSERT INTO user(full_name,date_of_birth,date_of_joining,contact_number,email_id,address,qualification,user_name,password,note,created_by_id,created_date,last_modified_by_id,last_modified_date) VALUES ('$full_name','$date_of_birth','$date_of_joining','$contact_number','$email_id','$address','$qualification','$user_name','$password','$note','$created_by_id','$created_date','$last_modified_by_id','$last_modified_date')";
if(mysqli_query($conn, $insert)){
	  echo "<script>alert('Record inserted successfully!')</script>";
	 // echo "<script>window.location='ViewProduct.php?Id=" . $proId . "'</script>";
	 echo "<script>window.location='login.php'</script>";
	 
}else{
echo "Could not insert record: ". mysqli_error($conn);
}
mysqli_close($conn);
/*
echo $email_id;
echo "<br/>";


echo $contact_number;
echo "<br/>";


echo $user_name;
echo "<br/>";


echo $password;
echo "<br/>";
*/




?>