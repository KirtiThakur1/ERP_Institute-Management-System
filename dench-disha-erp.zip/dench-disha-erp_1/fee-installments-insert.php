<?php

include "config.php";

if(isset($_GET['Id']))
        {
			$admission_id=$_GET['Id']; //Accepted URL parameter
			
			//$edit = $conn->query("SELECT * FROM admission WHERE admission_id=".$admission_id."");
            //$row = $edit->fetch_array();
        }


$full_name=$_POST["full_name"]; 

$course_id=$_POST["course_id"];

$course_name=$_POST["course_name"];

$batch_time=null;

$course_fee=$_POST["course_fees"];

$discount_amt=$_POST["discount_amount"];

$amount_paid=$_POST["amount_paid"];

$after_paid_fees=$_POST["after_paid_fees"];

$trainer=null;

$start_date=null;

$end_date=null;

$status=null;

$remarks=null;

//$admission_id=$_POST["admission_id"];


date_default_timezone_set('Asia/Kolkata');
$currentTime = date( 'h:i:s A', time () );
$currentDate= date( 'd-m-Y', time () );
$currentDateTime=date( 'd-m-Y h:i:s A', time () );


$created_by_id=NULL;
$created_date=$currentDateTime;
$last_modified_by_id=NULL;
$last_modified_date=NULL;



$insert = "INSERT INTO fee(full_name,course_id,course_name,admission_id,batch_and_timings,course_fees,discount_amount,amount_paid,remaining_amount,trainer,start_date,end_date,status,remarks,created_by_id,created_date,last_modified_by_id,last_modified_date) VALUES ('$full_name','$course_id','$course_name','$admission_id','$batch_time','$course_fee','$discount_amt','$amount_paid','$after_paid_fees','$trainer','$start_date','$end_date','$status','$remarks','$created_by_id','$created_date','$last_modified_by_id','$last_modified_date')";
if(mysqli_query($conn, $insert)){
	  echo "<script>alert('Record inserted successfully!')</script>";
	 // echo "<script>window.location='ViewProduct.php?Id=" . $proId . "'</script>";
	 echo "<script>window.location='admission-course.php?Id=" . $admission_id ."'</script>";
	 
}else{
echo "Could not insert record: ". mysqli_error($conn);
}
mysqli_close($conn);




?>