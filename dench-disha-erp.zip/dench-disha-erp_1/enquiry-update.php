<?php

include "config.php";

if(isset($_POST["update"]))
{
$enquiry_id=$_POST["enquiry_id"];	
$full_name=$_POST["full_name"];
$date_of_birth=$_POST["date_of_birth"];
$enquiry_date=$_POST["enquiry_date"];
$contact_number=$_POST["contact_number"];
$email_id=$_POST["email_id"];
$address=$_POST["address"];
$qualification=$_POST["qualification"];
$previous_knowledge=$_POST["previous_knowledge"];
$course_name=$_POST["course_name"];
$fees=$_POST["fees"];
$batch_and_timings=$_POST["batch_and_timings"];
$reference=$_POST["reference"];
$note=$_POST["note"];

date_default_timezone_set('Asia/Kolkata');
$currentTime = date( 'h:i:s A', time () );
$currentDate= date( 'd-m-Y', time () );
$currentDateTime=date( 'd-m-Y h:i:s A', time () );

//$created_by_id=NULL;
//$created_date=$currentDateTime;

$last_modified_by_id=NULL;
$last_modified_date=$currentDateTime;


$update = ("UPDATE enquiry SET full_name='".$full_name."', date_of_birth='".$date_of_birth."', enquiry_date='".$enquiry_date."', contact_number='".$contact_number."', email_id='".$email_id."', address='".$address."',qualification='".$qualification."', previous_knowledge='".$previous_knowledge."',course_name='".$course_name."',fees='".$fees."',batch_and_timings='".$batch_and_timings."',reference='".$reference."',note='".$note."',last_modified_by_id='".$last_modified_by_id."',last_modified_date='".$last_modified_date."' WHERE enquiry_id='".$enquiry_id."'");
	
if(mysqli_query($conn, $update)){
	  echo "<script>alert('Record updated successfully!')</script>";
	 // echo "<script>window.location='ViewProduct.php?Id=" . $proId . "'</script>";
	 echo "<script>window.location='enquiry-record.php'</script>";
	 
}else{
echo "Could not insert record: ". mysqli_error($conn);
}
mysqli_close($conn);

	
}

else{
	
	  echo "<script>alert('Record not updated!')</script>";
}


?>