<?php

include "config.php";


$full_name=$_POST["full_name"];

$date_of_birth=$_POST["date_of_birth"];

$enquiry_date =$_POST["enquiry_date"];

$email_id=$_POST["email_id"];

$contact_number=$_POST["contact_number"];

$address=$_POST["address"];

$qualification=$_POST["qualification"];

$prev_knowledge=$_POST["prev_knowledge"];

$course_name=$_POST["course_name"];

$fees=$_POST["fees"];

$batch_time=$_POST["batch_time"];

$reference=$_POST["reference"];

$note=$_POST["note"];


date_default_timezone_set('Asia/Kolkata');
$currentTime = date( 'h:i:s A', time () );
$currentDate= date( 'd-m-Y', time () );
$currentDateTime=date( 'd-m-Y h:i:s A', time () );


$created_by_id=NULL;
$created_date=$currentDateTime;
$last_modified_by_id=NULL;
$last_modified_date=NULL;



$insert = "INSERT INTO enquiry(full_name,date_of_birth,enquiry_date,contact_number,email_id,address,qualification,previous_knowledge,course_name,fees,batch_and_timings,reference,note,created_by_id,created_date,last_modified_by_id,last_modified_date) VALUES ('$full_name','$date_of_birth','$enquiry_date','$contact_number','$email_id','$address','$qualification','$prev_knowledge','$course_name','$fees','$batch_time','$reference','$note','$created_by_id','$created_date','$last_modified_by_id','$last_modified_date')";
if(mysqli_query($conn, $insert)){
	  echo "<script>alert('Record inserted successfully!')</script>";
	 // echo "<script>window.location='ViewProduct.php?Id=" . $proId . "'</script>";
	 echo "<script>window.location='enquiry-record.php'</script>";
	 
}else{
echo "Could not insert record: ". mysqli_error($conn);
}
mysqli_close($conn);
/*
echo $email_id;
echo "<br/>";


echo $contact_number;
echo "<br/>";


echo $user_name;
echo "<br/>";


echo $password;
echo "<br/>";
*/




?>