<?php

require 'config.php';

	if(isset($_GET['Id']))
	{
		$trainer_id=$_GET['Id'];
		
        $delete = ("DELETE FROM trainer WHERE trainer_id=".$trainer_id."");
                    
		if(mysqli_query($conn, $delete)){
			
			echo "<script>alert('Trainer record deleted')</script>";

			echo "<script>window.location='trainer-record.php'</script>";
	 
		}else{ 
				echo "Could not delete record: ". mysqli_error($conn);
			}
		mysqli_close($conn);

	
	}

else{
	
	  echo "<script>alert('Record not deleted!')</script>";
}

         
?>
